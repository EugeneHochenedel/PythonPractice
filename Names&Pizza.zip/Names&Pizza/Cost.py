def Pizza(TotalPrice, Radius):
	First = TotalPrice * Radius
	Slice = First / 20
	return Slice