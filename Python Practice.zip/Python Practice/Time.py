def hours(sec):
	return sec/3600
def minutes(sec):
	return sec/60
def seconds(sec):
	return sec