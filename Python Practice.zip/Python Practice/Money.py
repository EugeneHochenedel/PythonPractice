def Quarter(pen):
	return pen/25
def Dime(pen):
	return pen/10
def Nickel(pen):
	return pen/5
def Penny(pen):
	return pen